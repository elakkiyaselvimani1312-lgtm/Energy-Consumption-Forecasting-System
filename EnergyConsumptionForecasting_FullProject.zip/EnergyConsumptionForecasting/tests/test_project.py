import pandas as pd
import pytest
from src.data_processing import validate_data, prepare_data, make_sample_data
from src.forecasting import evaluate_forecasts, fit_and_forecast, available_models

def test_sample_data_has_required_columns():
    df = make_sample_data()
    assert {"Date", "Energy_Consumption"}.issubset(df.columns)

def test_sample_data_is_reproducible():
    pd.testing.assert_frame_equal(make_sample_data(), make_sample_data())

def test_empty_input_is_rejected():
    assert validate_data(pd.DataFrame())

def test_missing_column_is_reported():
    errors = validate_data(pd.DataFrame({"Date": ["2025-01-01"]}))
    assert any("Energy_Consumption" in e for e in errors)

def test_non_numeric_energy_is_rejected():
    errors = validate_data(pd.DataFrame({"Date":["2025-01-01"], "Energy_Consumption":["many"]}))
    assert any("numeric" in e for e in errors)

def test_negative_energy_is_rejected():
    errors = validate_data(pd.DataFrame({"Date":["2025-01-01"], "Energy_Consumption":[-3]}))
    assert any("negative" in e for e in errors)

def test_prepare_sorts_and_combines_duplicate_dates():
    raw = pd.DataFrame({"Date":["2025-01-02","2025-01-01","2025-01-01"],
                        "Energy_Consumption":[20,10,14]})
    data, notes = prepare_data(raw)
    assert data["Date"].is_monotonic_increasing
    assert data.loc[data["Date"] == pd.Timestamp("2025-01-01"), "Energy_Consumption"].iloc[0] == 12

def test_forecast_has_requested_horizon():
    data, _ = prepare_data(make_sample_data(100))
    forecast = fit_and_forecast(data, "Seasonal Naive (7-day)", 9)
    assert len(forecast) == 9
    assert forecast["Forecast_kWh"].notna().all()

def test_evaluation_is_chronological():
    data, _ = prepare_data(make_sample_data(100))
    result, metrics = evaluate_forecasts(data, "Seasonal Naive (7-day)")
    assert result["Date"].min() > data.iloc[int(len(data)*0.8)-1]["Date"]
    assert metrics["MAE"] >= 0

def test_all_models_available():
    assert len(available_models()) >= 3
