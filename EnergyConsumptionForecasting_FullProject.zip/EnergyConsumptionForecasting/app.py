import streamlit as st
import pandas as pd
import plotly.express as px
from src.data_processing import prepare_data, validate_data, make_sample_data
from src.forecasting import evaluate_forecasts, fit_and_forecast, available_models

st.set_page_config(page_title="Energy Forecasting", page_icon="⚡", layout="wide")
st.title("⚡ Energy Consumption Forecasting System")
st.caption("Explore historical electricity use and produce an evidence-based baseline forecast.")

with st.sidebar:
    st.header("Settings")
    uploaded = st.file_uploader("Upload energy data (CSV)", type=["csv"])
    st.markdown("**Required columns:** `Date`, `Energy_Consumption`")
    model_name = st.selectbox("Forecasting model", available_models())
    horizon = st.slider("Forecast horizon (days)", 1, 90, 14)
    use_sample = st.checkbox("Use built-in sample data", value=uploaded is None)

try:
    if uploaded is not None:
        raw = pd.read_csv(uploaded)
        source_name = uploaded.name
    elif use_sample:
        raw = make_sample_data()
        source_name = "Built-in synthetic sample"
    else:
        st.info("Upload a CSV or select the sample-data option to begin.")
        st.stop()

    errors = validate_data(raw)
    if errors:
        st.error("The input file needs attention:")
        for err in errors:
            st.write(f"- {err}")
        st.stop()

    data, quality_notes = prepare_data(raw)
    if len(data) < 20:
        st.warning("There are fewer than 20 valid daily records. Forecasts may be unreliable.")
    st.success(f"Loaded {len(data):,} daily records from: {source_name}")
    with st.expander("Data quality report", expanded=False):
        for note in quality_notes:
            st.write(f"- {note}")
        st.dataframe(data.head(20), use_container_width=True)

    total = data["Energy_Consumption"].sum()
    avg = data["Energy_Consumption"].mean()
    last_date = data["Date"].max()
    c1, c2, c3 = st.columns(3)
    c1.metric("Total energy", f"{total:,.1f} kWh")
    c2.metric("Average daily use", f"{avg:,.1f} kWh")
    c3.metric("Latest date", str(last_date.date()))

    st.subheader("Historical consumption")
    fig = px.line(data, x="Date", y="Energy_Consumption", title="Daily energy consumption", markers=False,
                  labels={"Energy_Consumption": "Energy (kWh)", "Date": "Date"})
    st.plotly_chart(fig, use_container_width=True)

    daily = data.assign(Day=data["Date"].dt.day_name()).groupby("Day", as_index=False)["Energy_Consumption"].mean()
    order = ["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"]
    daily["Day"] = pd.Categorical(daily["Day"], categories=order, ordered=True)
    daily = daily.sort_values("Day")
    fig2 = px.bar(daily, x="Day", y="Energy_Consumption", title="Average consumption by day of week",
                  labels={"Energy_Consumption":"Average energy (kWh)", "Day":"Day"})
    st.plotly_chart(fig2, use_container_width=True)

    st.subheader("Time-aware model evaluation")
    eval_df, metrics = evaluate_forecasts(data, model_name)
    if metrics:
        m1,m2,m3 = st.columns(3)
        m1.metric("MAE", f"{metrics['MAE']:.2f} kWh")
        m2.metric("RMSE", f"{metrics['RMSE']:.2f} kWh")
        m3.metric("MAPE", f"{metrics['MAPE']:.2f}%" if pd.notna(metrics["MAPE"]) else "Not defined")
        st.caption("Evaluation uses a chronological holdout: earlier observations train the model; later observations test it.")
        comparison = eval_df.copy()
        st.dataframe(comparison.tail(30), use_container_width=True)
        f_eval = px.line(comparison, x="Date", y=["Actual", "Predicted"], title="Actual vs predicted on held-out dates")
        st.plotly_chart(f_eval, use_container_width=True)
    else:
        st.warning("Not enough data to evaluate this model. Provide at least 20 valid daily records.")

    st.subheader(f"Forecast for the next {horizon} days")
    forecast = fit_and_forecast(data, model_name, horizon)
    st.dataframe(forecast, use_container_width=True)
    f_forecast = px.line(forecast, x="Date", y="Forecast_kWh", markers=True,
                         title="Forecasted daily energy consumption",
                         labels={"Forecast_kWh":"Forecast (kWh)", "Date":"Date"})
    st.plotly_chart(f_forecast, use_container_width=True)

    st.download_button("Download forecast CSV", forecast.to_csv(index=False).encode("utf-8"),
                       file_name="energy_forecast.csv", mime="text/csv")
    st.download_button("Download cleaned data CSV", data.to_csv(index=False).encode("utf-8"),
                       file_name="cleaned_energy_data.csv", mime="text/csv")
    st.info("Forecasts are estimates, not guarantees. Results depend on data quality, history length, changing usage, and external factors.")
except Exception as exc:
    st.error(f"Unable to process this input: {exc}")
    st.caption("Check the CSV format and required columns, then try again.")
