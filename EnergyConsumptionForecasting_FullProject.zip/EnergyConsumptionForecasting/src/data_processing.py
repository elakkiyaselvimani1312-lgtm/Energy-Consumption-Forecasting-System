import numpy as np
import pandas as pd

REQUIRED_COLUMNS = {"Date", "Energy_Consumption"}

def validate_data(df: pd.DataFrame) -> list[str]:
    errors = []
    if df is None or df.empty:
        return ["The file is empty."]
    missing = REQUIRED_COLUMNS - set(df.columns)
    if missing:
        errors.append("Missing required column(s): " + ", ".join(sorted(missing)))
        return errors
    dates = pd.to_datetime(df["Date"], errors="coerce")
    if dates.isna().all():
        errors.append("No valid dates were found in the Date column.")
    energy = pd.to_numeric(df["Energy_Consumption"], errors="coerce")
    if energy.notna().sum() == 0:
        errors.append("Energy_Consumption must contain numeric values.")
    if (energy.dropna() < 0).any():
        errors.append("Energy_Consumption cannot be negative.")
    return errors

def prepare_data(df: pd.DataFrame) -> tuple[pd.DataFrame, list[str]]:
    work = df.copy()
    notes = []
    before = len(work)
    work["Date"] = pd.to_datetime(work["Date"], errors="coerce")
    work["Energy_Consumption"] = pd.to_numeric(work["Energy_Consumption"], errors="coerce")
    invalid = work[["Date", "Energy_Consumption"]].isna().any(axis=1).sum()
    if invalid:
        notes.append(f"Removed {invalid} row(s) with invalid date or energy values.")
    work = work.dropna(subset=["Date", "Energy_Consumption"])
    negative = (work["Energy_Consumption"] < 0).sum()
    if negative:
        notes.append(f"Removed {negative} row(s) with negative energy values.")
        work = work[work["Energy_Consumption"] >= 0]
    dup = work.duplicated(subset=["Date"]).sum()
    if dup:
        notes.append(f"Combined duplicate dates by taking their mean ({dup} duplicate row(s)).")
    work = work.groupby("Date", as_index=False)["Energy_Consumption"].mean()
    work = work.sort_values("Date").reset_index(drop=True)
    if len(work) < before:
        notes.append(f"Prepared {len(work)} usable daily records from {before} input rows.")
    # Daily resampling makes the target frequency explicit. Missing days remain missing,
    # then are time-interpolated only between known observations.
    if not work.empty:
        work = work.set_index("Date").asfreq("D")
        missing_days = work["Energy_Consumption"].isna().sum()
        if missing_days:
            notes.append(f"Filled {missing_days} missing calendar day(s) by time interpolation.")
            work["Energy_Consumption"] = work["Energy_Consumption"].interpolate(method="time", limit_area="inside")
            work["Energy_Consumption"] = work["Energy_Consumption"].ffill().bfill()
        work = work.reset_index()
    if not notes:
        notes.append("No major data-quality issues were found.")
    return work, notes

def make_sample_data(n_days: int = 540, seed: int = 42) -> pd.DataFrame:
    """Synthetic example data; it is not real meter data."""
    rng = np.random.default_rng(seed)
    dates = pd.date_range("2024-01-01", periods=n_days, freq="D")
    t = np.arange(n_days)
    weekly = 9 * np.sin(2 * np.pi * t / 7)
    yearly = 15 * np.sin(2 * np.pi * t / 365.25)
    trend = 0.025 * t
    noise = rng.normal(0, 5, n_days)
    energy = np.maximum(15, 120 + weekly + yearly + trend + noise)
    return pd.DataFrame({"Date": dates, "Energy_Consumption": energy.round(2)})
