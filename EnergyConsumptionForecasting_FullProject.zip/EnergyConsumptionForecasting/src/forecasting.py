import numpy as np
import pandas as pd
from sklearn.ensemble import HistGradientBoostingRegressor, RandomForestRegressor
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, mean_squared_error
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

def available_models():
    return ["Seasonal Naive (7-day)", "Linear Regression", "Random Forest", "Gradient Boosting"]

def _features(dates: pd.Series, values: pd.Series | None = None, origin=None) -> pd.DataFrame:
    dates = pd.to_datetime(dates)
    out = pd.DataFrame({
        "trend": (dates - pd.Timestamp(origin or dates.min())).dt.days.astype(float),
        "dow_sin": np.sin(2*np.pi*dates.dt.dayofweek/7),
        "dow_cos": np.cos(2*np.pi*dates.dt.dayofweek/7),
        "year_sin": np.sin(2*np.pi*dates.dt.dayofyear/365.25),
        "year_cos": np.cos(2*np.pi*dates.dt.dayofyear/365.25),
    })
    if values is not None:
        vals = pd.Series(values).reset_index(drop=True)
        # Lag values are useful for tree and linear models; use only past values.
        for lag in (1, 7, 14):
            out[f"lag_{lag}"] = vals.shift(lag).to_numpy()
    return out

def _make_model(name):
    if name == "Linear Regression":
        return make_pipeline(StandardScaler(), LinearRegression())
    if name == "Random Forest":
        return RandomForestRegressor(n_estimators=250, min_samples_leaf=3, random_state=42, n_jobs=-1)
    if name == "Gradient Boosting":
        return HistGradientBoostingRegressor(max_iter=200, learning_rate=0.06, l2_regularization=1.0, random_state=42)
    raise ValueError(f"Unknown model: {name}")

def _metric_dict(actual, predicted):
    actual = np.asarray(actual, dtype=float)
    predicted = np.asarray(predicted, dtype=float)
    mae = mean_absolute_error(actual, predicted)
    rmse = float(np.sqrt(mean_squared_error(actual, predicted)))
    nonzero = np.abs(actual) > 1e-9
    mape = float(np.mean(np.abs((actual[nonzero] - predicted[nonzero]) / actual[nonzero])) * 100) if nonzero.any() else np.nan
    return {"MAE": float(mae), "RMSE": rmse, "MAPE": mape}

def _predict_with_lags(model_name, train_dates, train_values, target_dates):
    origin = pd.Timestamp(train_dates.iloc[0])
    history_dates = list(pd.to_datetime(train_dates))
    history_values = list(np.asarray(train_values, dtype=float))
    predictions = []
    if model_name == "Seasonal Naive (7-day)":
        for target in pd.to_datetime(target_dates):
            # Forecast same weekday using last observed value from seven days before.
            idx = len(history_values) - 7
            pred = history_values[idx] if idx >= 0 else float(np.mean(history_values))
            predictions.append(pred)
            history_dates.append(target)
            history_values.append(pred)
        return np.asarray(predictions)
    model = _make_model(model_name)
    # Train with rolling historical lag features, dropping the first 14 rows.
    tr_dates = pd.Series(pd.to_datetime(train_dates).reset_index(drop=True))
    tr_values = pd.Series(np.asarray(train_values, dtype=float))
    X = _features(tr_dates, tr_values, origin=origin)
    y = tr_values
    valid = X[["lag_1", "lag_7", "lag_14"]].notna().all(axis=1)
    model.fit(X.loc[valid], y.loc[valid])
    for target in pd.to_datetime(target_dates):
        dates_all = pd.Series(pd.to_datetime(history_dates))
        vals_all = pd.Series(history_values)
        feat = _features(pd.Series([target]), origin=origin)
        feat["lag_1"] = vals_all.iloc[-1]
        feat["lag_7"] = vals_all.iloc[-7] if len(vals_all) >= 7 else vals_all.mean()
        feat["lag_14"] = vals_all.iloc[-14] if len(vals_all) >= 14 else vals_all.mean()
        pred = float(model.predict(feat)[0])
        pred = max(0.0, pred)
        predictions.append(pred)
        history_dates.append(target)
        history_values.append(pred)
    return np.asarray(predictions)

def evaluate_forecasts(data: pd.DataFrame, model_name: str, test_fraction: float = 0.2):
    if len(data) < 20:
        return pd.DataFrame(), {}
    split = max(14, int(len(data) * (1-test_fraction)))
    split = min(split, len(data)-1)
    train = data.iloc[:split].reset_index(drop=True)
    test = data.iloc[split:].reset_index(drop=True)
    pred = _predict_with_lags(model_name, train["Date"], train["Energy_Consumption"], test["Date"])
    out = pd.DataFrame({"Date": test["Date"], "Actual": test["Energy_Consumption"], "Predicted": pred})
    return out, _metric_dict(out["Actual"], out["Predicted"])

def fit_and_forecast(data: pd.DataFrame, model_name: str, horizon: int):
    if len(data) < 15:
        raise ValueError("At least 15 valid daily records are needed to generate a forecast.")
    dates = pd.to_datetime(data["Date"]).reset_index(drop=True)
    values = pd.to_numeric(data["Energy_Consumption"]).reset_index(drop=True)
    future_dates = pd.date_range(dates.max() + pd.Timedelta(days=1), periods=horizon, freq="D")
    pred = _predict_with_lags(model_name, dates, values, pd.Series(future_dates))
    return pd.DataFrame({"Date": future_dates, "Forecast_kWh": np.round(pred, 2)})
